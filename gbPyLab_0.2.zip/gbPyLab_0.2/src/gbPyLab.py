import wx
import labDlg
import random
import os
import sys
import thread
import  wx.lib.newevent

#----------------------------------------------------------------------
(UpdateComputeLabEvent, EVT_COMPUTE_LAB) = wx.lib.newevent.NewEvent()

#----------------------------------------------------------------------
class ComputeLabThread:
    def __init__(self, win, listeMurs, listeVisite):
        self._listeMurs = listeMurs
        self._listeVisite=listeVisite
        self.win = win

    def Start(self):
        self.keepGoing = self.running = True
        thread.start_new_thread(self.Run, ())

    def Stop(self):
        self.keepGoing = False

    def IsRunning(self):
        return self.running

    def getMurs(self):
        return self._listeMurs

    def Run(self):
        etatPct = 0
        max=len(self._listeVisite[2])
        old=max
        while self.keepGoing and old>0:
            old=creuseLab(self._listeMurs,self._listeVisite)
            etatPct= (float(max-old)/max)*100.0
            evt = UpdateComputeLabEvent(etatPct=etatPct)
            wx.PostEvent(self.win, evt)

        self.running = False

#------------------------------------------------------------------------------
def LoadLab(path):
    fobj=open(path,"r")
    l=fobj.readline()
    if l.find("Dim(")!=0:
        return None
    l=l.strip()
    sx,sy=l[4:len(l)-1].split(',')
    sx=int(sx); sy=int(sy)

    liste=[]
    for y in range(0,sy):
        l=fobj.readline()
        l = l.strip().split(']')
        for x in l:
            if len(x)>0:
                elt= x.split(',')
                elt[0]=elt[0][1]
                elti=[]
                for i in elt:
                    elti.append(int(i))
                liste.append(elti)
    
    return (sx,sy,liste)

#------------------------------------------------------------------------------
def SaveLab(lab, path):
    fobj=open(path,"w")
    xl,yl,l=lab
    fobj.write("Dim(%d,%d)\n"%(xl,yl))
    for y in range(0,yl):
        for x in range(0,xl):
            fobj.write("[%d,%d,%d,%d]"%(l[x+(y*yl)][0],l[x+(y*yl)][1],l[x+(y*yl)][2],l[x+(y*yl)][3]))
        fobj.write("\n")
    
    
#------------------------------------------------------------------------------
# La liste retournee est composee de
# x,y     - taille en x,y
# liste   - liste (de taille x,y) d'elements indiquant la presence des murs gauche/haut/droit/bas
def defMurs(x,y):
    liste=[]
    for a in range(0,y):
        for b in range(0,x):
            elt=[1,1,1,1]
            liste.append(elt)
    return (x,y,liste)
    
#------------------------------------------------------------------------------
# La liste retournee est composee de
# x,y     - taille en x,y
# liste   - liste de booleens de taille x,y
def defVisite(x,y):
    liste=[]
    for a in range(0,y):
        for b in range(0,x):
            liste.append(False)
    return (x,y,liste)

#------------------------------------------------------------------------------
# Retourne une pos x,y a partir d'une position globale
# et d'une largeur W
def posXYFromGlobale(pos, W):
    return [pos%W, pos//W]

#------------------------------------------------------------------------------
# Retourne une pos globale a partir d'une position XY
# et d'une largeur W
#
# posXY est compose de [x,y]
def posGlobaleFromXY(posXY, W):
    return posXY[0]+(posXY[1]*W)

#------------------------------------------------------------------------------
# On verifie si autour tout est visite
def allVisited(newPos,visite):
    pos=newPos[:]
    if (pos[0]+1)<visite[0] and visite[2][posGlobaleFromXY((pos[0]+1,pos[1]),visite[0])]==False:
        return False
    if (pos[0]-1)>=0 and visite[2][posGlobaleFromXY((pos[0]-1,pos[1]),visite[0])]==False:
        return False
    if (pos[1]+1)<visite[1] and visite[2][posGlobaleFromXY((pos[0],pos[1]+1),visite[0])]==False:
        return False
    if (pos[1]-1)>=0 and visite[2][posGlobaleFromXY((pos[0],pos[1]-1),visite[0])]==False:
        return False
    return True

#------------------------------------------------------------------------------
#  Indique si une position est en-dehors du labyrinthe ou non
def isOut(pos, lab):
    w,h,lAr = lab
    x,y=pos
    if x<0 or y<0 or x>=w or y>=h:
        return True
    return False


#------------------------------------------------------------------------------
#  Indique si une position est visitee ou non
def isVisited(pos,visite):
    w,h,vAr = visite
    x,y=pos
    
    if isOut(pos,visite):
        return False
        
    pos=posGlobaleFromXY(pos,w)
    if vAr[pos]==1:
        return True
    
    return False
    
#------------------------------------------------------------------------------
# Ouvre un acces vers une zone deja visitee
def openToVisited(labAll,visite,newPos):
    w,h,lab = labAll
    zVisited=[0,0,0,0] # Table des zones visitees autour de la position
                        # new pos
    x,y=newPos
    nbVisited=0                    
    if isVisited([x-1,y],visite): # Gauche
        zVisited[0]=1
        nbVisited+=1
    if isVisited([x,y-1],visite): # Haut
        zVisited[1]=1
        nbVisited+=1
    if isVisited([x+1,y],visite): # Droit
        zVisited[2]=1
        nbVisited+=1
    if isVisited([x,y+1],visite): # Bas
        zVisited[3]=1
        nbVisited+=1
        
    if nbVisited==0:
        return
    
    # tirage aleatoire d'une zone visitee
    rZone=random.randint(1,nbVisited)
    for z in range(0,len(zVisited)):
        if zVisited[z]==1:
            if rZone!=1:
                zVisited[z]=0
            rZone-=1
            
    if zVisited[0]==1: # gauche
        lab[posGlobaleFromXY(newPos,w)][0]=0
        lab[posGlobaleFromXY([x-1,y],w)][2]=0
    elif  zVisited[1]==1: # haut
        lab[posGlobaleFromXY(newPos,w)][1]=0
        lab[posGlobaleFromXY([x,y-1],w)][3]=0
    elif  zVisited[2]==1: # droite
        lab[posGlobaleFromXY(newPos,w)][2]=0
        lab[posGlobaleFromXY([x+1,y],w)][0]=0
    elif zVisited[3]==1: # Bas
        lab[posGlobaleFromXY(newPos,w)][3]=0
        lab[posGlobaleFromXY([x,y+1],w)][1]=0

#------------------------------------------------------------------------------
# Creuse le labyrinth
# 
# La methode retourne le nombre de case non visitee
#
def creuseLab(lab,visite):
    #------------------------------------------------------
    # On prend la position de depart aleatoirement dans les places
    # non initialisees
    
    # construction de la liste des places non visitees
    lv=[]
    for x in range(0,len(visite[2])):
        if visite[2][x]==False:
            lv.append(x)
    if len(lv)==0:
        return 0
    
    random.shuffle(lv)
    oldPos = posXYFromGlobale(lv[0],lab[0])
    newPos = oldPos[:] # copie
    width=lab[0]; height=lab[1]
    
    visite[2][posGlobaleFromXY(newPos,width)]=True
    retour=len(lv)-1
    lv=[]
    
    # On ouvre un acces vers une zone deja visitee
    openToVisited(lab,visite,newPos)
   
    # Tant que l'on n'est pas sorti de la grille
    while newPos[0]>=0 and newPos[0]<width and newPos[1]>=0 and newPos[1]<height:
        
        # Iter
        sys.stdout.flush()
        
        
        # On verifie, qu'autour tout n'est pas visite
        if allVisited(newPos,visite):
            # On ouvre un acces vers une zone deja visitee
            openToVisited(lab,visite,newPos)
            return retour
        
        # choix d'une direction de deplacement
        dir=random.randint(1,4) # 1= gauche, 2=haut, 3=droite, 4=bas
        
        if dir==1: # gauche
            newPos[0]-=1
        elif  dir==2: # haut
            newPos[1]-=1
        elif  dir==3: # droite
            newPos[0]+=1
        else: # bas
            newPos[1]+=1
            
        # Si on ...
        if newPos[0]>=0 and newPos[0]<width and newPos[1]>=0 and newPos[1]<height:
            # ... n'est pas en dehors de la grille
            
            # et que la nouvelle position est ....
            if visite[2][posGlobaleFromXY(newPos,width)]==False:
                # ... non visitee
                
                visite[2][posGlobaleFromXY(newPos,width)]=True
                retour-=1

                # On ouvre les murs des cases contigues
                if dir==1: # gauche
                    lab[2][posGlobaleFromXY(oldPos,width)][0]=0
                    lab[2][posGlobaleFromXY(newPos,width)][2]=0
                elif  dir==2: # haut
                    lab[2][posGlobaleFromXY(oldPos,width)][1]=0
                    lab[2][posGlobaleFromXY(newPos,width)][3]=0
                elif  dir==3: # droite
                    lab[2][posGlobaleFromXY(oldPos,width)][2]=0
                    lab[2][posGlobaleFromXY(newPos,width)][0]=0
                else: # bas
                    lab[2][posGlobaleFromXY(oldPos,width)][3]=0
                    lab[2][posGlobaleFromXY(newPos,width)][1]=0
                    
                oldPos = newPos[:]
                
            else:
                # ... visitee, alors on cherche une autre position
                newPos = oldPos[:]
        else:
            # ... est en dehors de la grille
            pass # on ne fait rien
            """
            # On ouvre le mur donnant vers l'exterieur
            if dir==1: # gauche
                lab[2][posGlobaleFromXY(oldPos,width)][0]=0
            elif  dir==2: # haut
                lab[2][posGlobaleFromXY(oldPos,width)][1]=0
            elif  dir==3: # droite
                lab[2][posGlobaleFromXY(oldPos,width)][2]=0
            else: # bas
                lab[2][posGlobaleFromXY(oldPos,width)][3]=0
            """
    return retour

#------------------------------------------------------------------------------
class MyFrame(wx.Frame):

    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, -1, title,
                          pos=(150, 150), size=(430, 220))

        self._lab=None

        panel = wx.Panel(self)
        sizer = wx.BoxSizer(wx.VERTICAL)

        fgs = wx.FlexGridSizer(cols=3)
        fgs.AddGrowableCol(1)
        text = wx.StaticText(panel, -1, "Labyrinth")
        text.SetFont(wx.Font(14, wx.SWISS, wx.NORMAL, wx.BOLD))
        text.SetSize(text.GetBestSize())
        b = wx.Button(panel, 5, "About")
        self.Bind(wx.EVT_BUTTON, self.OnClickAbout, b)
        b.SetDefault()
        b.SetSize(b.GetBestSize())
        fgs.Add(text, 0, wx.EXPAND)
        fgs.Add((60,10), 0, wx.EXPAND)
        fgs.Add(b, 0, wx.EXPAND)

        sizer.Add(fgs, 0, wx.EXPAND|wx.ALL, 10)

        box = wx.BoxSizer(wx.HORIZONTAL)
        fgs = wx.FlexGridSizer(cols=2, hgap=5, vgap=5)
        l1 = wx.StaticText(panel, -1, "# row")
        self._nbLigne = wx.TextCtrl(panel, -1, "10")
        fgs.Add(l1, 0, wx.EXPAND)
        fgs.Add(self._nbLigne, 0, wx.EXPAND)
        
        box.Add(fgs, 0, wx.EXPAND|wx.ALL, 5)

        fgs = wx.FlexGridSizer(cols=2, hgap=5, vgap=5)
        l1 = wx.StaticText(panel, -1, "# col")
        self._nbColonne = wx.TextCtrl(panel, -1, "10")
        fgs.Add(l1, 0, wx.EXPAND)
        fgs.Add(self._nbColonne, 0, wx.EXPAND)
        
        box.Add(fgs, 0, wx.EXPAND|wx.ALL, 5)
        sizer.Add(box, 0, wx.ALL, 10)

        fgs = wx.FlexGridSizer(cols=4, hgap=15, vgap=5)
        l1 = wx.StaticText(panel, -1, "cube size")
        self._sizeCarre = wx.TextCtrl(panel, -1, "10")
        self._computeBtn = wx.Button(panel, 10, "Compute lab")
        self.Bind(wx.EVT_BUTTON, self.OnClickCompute, self._computeBtn)
        self._computeBtn.SetSize(self._computeBtn.GetBestSize())
        self._gauge = wx.Gauge(panel, -1, 100)
        fgs.Add(l1, 0, wx.EXPAND)
        fgs.Add(self._sizeCarre, 0, wx.EXPAND)
        fgs.Add(self._computeBtn, 0, wx.EXPAND)
        fgs.Add(self._gauge, 0, wx.EXPAND)
        
        sizer.Add(fgs, 0, wx.ALL, 10)

        fgs = wx.FlexGridSizer(cols=3, hgap=35, vgap=5)
        b2 = wx.Button(panel, 20, "Display lab")
        self.Bind(wx.EVT_BUTTON, self.OnClickDisplay, b2)
        b2.SetSize(b2.GetBestSize())
        fgs.Add(b2, 0, wx.EXPAND)
        b3 = wx.Button(panel, 30, "Save lab")
        self.Bind(wx.EVT_BUTTON, self.OnClickSave, b3)
        b3.SetSize(b3.GetBestSize())
        fgs.Add(b3, 0, wx.EXPAND)
        b4 = wx.Button(panel, 40, "Load lab")
        self.Bind(wx.EVT_BUTTON, self.OnClickLoad, b4)
        b4.SetSize(b4.GetBestSize())
        fgs.Add(b4, 0, wx.EXPAND)
        sizer.Add(fgs, 0, wx.ALL, 10)
        
        panel.SetSizer(sizer)
        panel.Layout()
        
        self.Bind(EVT_COMPUTE_LAB, self.OnComputeUpdate)
        
    def OnComputeUpdate(self, evt):
        self._gauge.SetValue(evt.etatPct)
        if evt.etatPct==100:
            self._lab=self._thread.getMurs()
            self._thread.Stop()
            self._thread=None
            self._computeBtn.Enable(True)
            
    def OnClickAbout(self,evt):
        info = wx.AboutDialogInfo()
        info.Name = "GBE Labyrinth"
        info.Version = "0.0.2"
        info.Copyright = "(C) 2007 G. Betteto"
        info.Description = "Just a python program to build a labyrinth"
        info.Developers = ["Gilles Betteto - gilbe@users.sourceforge.net"]
        info.License = "The GNU General Public License (GPL) - Version 3, 29 June 2007"
        wx.AboutBox(info)
    
    def OnClickCompute(self, evt):
        x=int(self._nbColonne.GetValue())
        y=int(self._nbLigne.GetValue())
        listeMurs = defMurs(x,y)
        listeVisite=defVisite(x,y)

        self._thread=ComputeLabThread(self, listeMurs, listeVisite)
        self._computeBtn.Enable(False)
        self._thread.Start()
    
    def OnClickSave(self, evt):
        if self._lab!=None:
            wildcard = "Labyrinth (*.lab)|*.lab|"     \
               "All files (*.*)|*.*"
            dlg = wx.FileDialog(
                self, message="Save file as ...", defaultDir=os.getcwd(), 
                defaultFile="", wildcard=wildcard, style=wx.SAVE
                )
            if dlg.ShowModal() == wx.ID_OK:
                path = dlg.GetPath()
                SaveLab(self._lab, path)

    
    def OnClickLoad(self, evt):
        wildcard = "Labyrinth (*.lab)|*.lab|"     \
               "All files (*.*)|*.*"
        dlg = wx.FileDialog(
            self, message="Choose a file",
            defaultDir=os.getcwd(), 
            defaultFile="",
            wildcard=wildcard,
            style=wx.OPEN | wx.MULTIPLE | wx.CHANGE_DIR
            )
        if dlg.ShowModal() == wx.ID_OK:
            self._lab=LoadLab(dlg.GetPath())
            if self._lab==None:
                dlg = wx.MessageDialog(self, 'File is not a Lab one',
                               'File error',
                               wx.OK | wx.ICON_ERROR)
                dlg.ShowModal()
                dlg.Destroy()
            else:
                self._nbColonne.SetValue(str(self._lab[0]))
                self._nbLigne.SetValue(str(self._lab[1]))

    
    def OnClickDisplay(self,evt):
        if self._lab!=None:
            labDlg.LabFrame(self,int(self._sizeCarre.GetValue()),self._lab).Show()

class MyApp(wx.App):
    def OnInit(self):
        frame = MyFrame(None, "PyLab - GBE")
        self.SetTopWindow(frame)

        frame.Show(True)
        return True
        
app = MyApp(redirect=False)
app.MainLoop()
