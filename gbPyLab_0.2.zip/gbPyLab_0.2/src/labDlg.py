import wx

#---------------------------------------------------------------------------

class LabScrollWin(wx.ScrolledWindow):
    def __init__(self, parent, sizeCarre, listeMurs):
        wx.ScrolledWindow.__init__(self, parent, -1)
        
        self._lMurs=listeMurs
        self._sizeCarre = sizeCarre
        
        self.Bind(wx.EVT_PAINT, self.OnPaint)
        self.SetVirtualSize((listeMurs[0]*sizeCarre, listeMurs[1]*sizeCarre))
        self.SetScrollRate(20,20)

        self.buffer = wx.EmptyBitmap(listeMurs[0]*sizeCarre, listeMurs[1]*sizeCarre)
        dc = wx.BufferedDC(None, self.buffer)
        dc.SetBackground(wx.BLACK_BRUSH)
        dc.Clear()
        self.doDrawing(dc)

    def doDrawing(self, dc):
        dc.SetPen(wx.WHITE_PEN)
        
        px=0; py=0
        for y in range(0,self._lMurs[1]):
            for x in range(0,self._lMurs[0]):
                elt = self._lMurs[2][x+(y*self._lMurs[0])]
                if elt[0]==1:
                    dc.DrawLines([[0,0],[0,self._sizeCarre-1]],px,py)
                if elt[1]==1:
                    dc.DrawLines([[0,0],[self._sizeCarre-1,0]],px,py)
                if elt[2]==1:
                    dc.DrawLines([[self._sizeCarre-1,0],[self._sizeCarre-1,self._sizeCarre-1]],px,py)
                if elt[3]==1:
                    dc.DrawLines([[0,self._sizeCarre-1],[self._sizeCarre-1,self._sizeCarre-1]],px,py)
                px+=self._sizeCarre
            px=0
            py+=self._sizeCarre
        
    def OnPaint(self, evt):
        dc = wx.PaintDC(self)
        dc.SetBackground(wx.BLACK_BRUSH)
        dc.Clear()
        dc = wx.BufferedPaintDC(self, self.buffer, wx.BUFFER_VIRTUAL_AREA)


#------------------------------------------------------------------------------
class LabFrame(wx.Frame):

    def __init__(self, parent,sizeCarre, listeMurs):
        wx.Frame.__init__(self, parent, -1, "Lab",pos=(150, 150), size=(150,150))
        LabScrollWin(self,sizeCarre,listeMurs)
