Project: gbPyLab

by G. Betteto
2007

Just a little python application to build a Labyrinth

Features:
- select number of rows and col
- load/save a lab
- display a lab

Needs:
- Python 2.5
- wxPython 2.8

Licence: GPL v3

To start:
just launch with python "gbPyLab.py"